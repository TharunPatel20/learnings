package com.wecp.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import com.wecp.entities.User;
import com.wecp.entities.UserTransaction;
import com.wecp.repos.UserRepository;
import com.wecp.repos.UserTransactionRepository;

@RestController
@CrossOrigin("*")
public class UserTransactionController {

    @Autowired
    private UserTransactionRepository userTransactionRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/transaction")
    @Transactional
    public ResponseEntity<?> transact(@RequestBody UserTransaction transaction) throws Exception {
		if (transaction.getTransactionAmount() == null ||
		transaction.getTransactionType() == null ||
		transaction.getUserId() == null) {
		return ResponseEntity.badRequest().body(Map.of("error", "Missing required fields"));
	}
	
	User user = userRepository.findByUserId(transaction.getUserId());
	if (user == null) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "User not found"));
	}
	

        Double amount = transaction.getTransactionAmount();
        Double current = user.getOustanding();

        if ("CREDIT".equalsIgnoreCase(transaction.getTransactionType())) {
            user.setOustanding(current + amount);
        } else if ("DEBIT".equalsIgnoreCase(transaction.getTransactionType())) {
            if (current < amount) {
                throw new Exception("NOT_ENOUGH_BALANCE");
            }
            user.setOustanding(current - amount);
        } else {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid transaction type"));
        }

        transaction.setUser(user);
		

        transaction.setBalance(user.getOustanding());

        userTransactionRepository.save(transaction);
        userRepository.save(user);

        return ResponseEntity.ok(Map.of("success", "Transaction performed successfully"));
    }

    @GetMapping("/all-transactions")
    @PreAuthorize("hasRole('CLIENT')")
    public ResponseEntity<?> getAllTransactions(@RequestParam String userId) {
        User user = userRepository.findByUserId(userId);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "User not found"));
        }
        return ResponseEntity.ok(user.getTransactions());
    }
}