package com.wecp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import com.wecp.config.JwtTokenUtil;
import com.wecp.model.JwtRequest;
import com.wecp.model.JwtResponse;
import com.wecp.repos.UserRepository;

@RestController
@CrossOrigin("*")
public class JwtAuthenticationController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService jwtInMemoryUserDetailsService;

	@Autowired
	private UserRepository userRepository;
	

	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest request) throws Exception {
		// Find user manually
		com.wecp.entities.User user = userRepository.findByUserId(request.getUsername());
		if (user == null || !user.getPassword().equals(request.getPassword())) {
			return ResponseEntity.status(401).body("Incorrect username or password");
		}
	
		// Manually build UserDetails
		UserDetails userDetails = org.springframework.security.core.userdetails.User
			.withUsername(user.getUserId())
			.password(user.getPassword())
			.roles(user.getRole().toUpperCase()) // Converts ADMIN to ROLE_ADMIN
			.build();
	
		String token = jwtTokenUtil.generateToken(userDetails);
		return ResponseEntity.ok(new JwtResponse(token));
	}

}
