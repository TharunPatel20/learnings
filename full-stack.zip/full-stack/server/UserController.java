package com.wecp.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.wecp.entities.User;
import com.wecp.repos.UserRepository;

@RestController
@CrossOrigin("*")
public class UserController {

    @Autowired
    UserRepository repository;

    @PostMapping("/user")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> saveUser(@RequestBody User user) {
        if (user.getUserId() == null || user.getPassword() == null || user.getRole() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing mandatory fields"));
        }

        User existing = repository.findByUserId(user.getUserId());

        if (existing == null) {
            repository.save(user);
        } else {
            existing.setPassword(user.getPassword());
            existing.setRole(user.getRole());
            repository.save(existing);
        }

        return ResponseEntity.ok(Map.of("success", "User saved successfully"));
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(repository.findAll());
    }
}
