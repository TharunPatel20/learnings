import { httpClient } from '../BaseApi';

// POST request to /authenticate
export const login = async (user) => {
    try {
        const response = await httpClient.post('/authenticate', user);
        setToken(response.data.token);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Authentication failed');
    }
};

export const getToken = () => {
    return localStorage.getItem("token");
};

export const setToken = (token) => {
    return localStorage.setItem('token', token);
};

// GET request to /fetchusers
export const getUsers = async () => {
    try {
        const response = await httpClient.get('/fetchusers');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to fetch users');
    }
};

// POST request to /user
export const createUser = async (user) => {
    try {
        const response = await httpClient.post('/user', user);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to create user');
    }
};