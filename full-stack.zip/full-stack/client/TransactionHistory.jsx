import React from "react";
import styles from "./Transaction.module.css";

function TransactionHistory({ transactions }) {
  return (
    <table className={styles.transactionHistory}>
      <thead>
        <tr>
          <th>Transaction Amount</th>
          <th>Transaction Type</th>
        </tr>
      </thead>
      <tbody>
        {transactions && transactions.length > 0 ? (
          transactions.map((transaction, index) => (
            <tr key={index}>
              <td>{transaction.transactionAmount}</td>
              <td>{transaction.transactionType}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={2} key="no-records">No transactions found.</td>
          </tr>
        )}
      </tbody>
    </table>
  );
}

export default TransactionHistory;