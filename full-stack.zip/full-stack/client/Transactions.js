import { httpClient } from "../BaseApi";

// POST request to /transaction
export const performTransaction = async (transaction) => {
    try {
        const response = await httpClient.post('/transaction', {
            userId: transaction.userId,
            transactionAmount: transaction.transactionAmount,
            transactionType: transaction.transactionType
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Transaction failed');
    }
};

// GET request to /out-standing with userId as query parameter
export const getOutstandingBalance = async (userId) => {
    try {
        const response = await httpClient.get(`/out-standing?userId=${encodeURIComponent(userId)}`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to fetch balance');
    }
};

// GET request to /all-transactions with userId as query parameter
export const getAllTranactions = async (userId) => {
    try {
        const response = await httpClient.get(`/all-transactions?userId=${encodeURIComponent(userId)}`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to fetch transactions');
    }
};