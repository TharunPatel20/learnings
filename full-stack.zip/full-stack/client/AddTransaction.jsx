import React, { useEffect, useState } from "react";
import styles from "./Transaction.module.css";
import { useSearchParams } from "react-router-dom";
import {
  getAllTranactions,
  getOutstandingBalance,
  performTransaction,
} from "./Transactions";
import TransactionHistory from "./TransactionHistory";
import Logout from "../User/Logout";

function AddTransaction() {
  const [userId, setUserId] = useState();
  const [transactionAmount, setTransactionAmount] = useState("");
  const [transactionType, setTransactionType] = useState("CREDIT");
  const [searchParams] = useSearchParams();
  const [balance, setBalance] = useState();
  const [transactions, setTransactions] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const id = searchParams.get("userId");
    setUserId(id);
    if (id) {
      fetchData(id);
    }
  }, [searchParams]);

  const fetchData = async (userId) => {
    try {
      const balanceData = await getOutstandingBalance(userId);
      setBalance(balanceData.outstanding);
      const transactionData = await getAllTranactions(userId);
      setTransactions(transactionData);
    } catch (err) {
      setError(err.message || "Failed to fetch data");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitted(true);
    setError("");
    setMessage("");

    if (!transactionAmount || transactionAmount <= 0) {
      return;
    }

    try {
      const response = await performTransaction({
        userId,
        transactionAmount: parseFloat(transactionAmount),
        transactionType
      });
      setMessage(response.success || "Transaction successful");
      setTransactionAmount("");
      setSubmitted(false);
      fetchData(userId); // Refresh balance and transactions
    } catch (err) {
      setError(err.message || "Transaction failed");
    }
  };

  return (
    <>
      <Logout />
      <h2>Make a Transaction</h2>
      <form className={styles.transactionForm} onSubmit={handleSubmit}>
        <div className={styles.formGroup}>
          <label>{userId}</label>
          <label data-testid="balance">Outstanding Balance: {balance}</label>
        </div>
        <div className={styles.formGroup}>
          <label>Amount:</label>
          <input
            type="number"
            className={styles.formControl}
            value={transactionAmount}
            onChange={(e) => setTransactionAmount(e.target.value)}
            min="0"
            step="0.01"
          />
          {submitted && (!transactionAmount || transactionAmount <= 0) && (
            <p className={styles.error}>Valid amount is required</p>
          )}
        </div>

        <div className={styles.formGroup}>
          <label>Type:</label>
          <select
            id="type"
            className={styles.formControl}
            value={transactionType}
            onChange={(e) => setTransactionType(e.target.value)}
          >
            <option value="CREDIT">Credit</option>
            <option value="DEBIT">Debit</option>
          </select>
        </div>
        <button type="submit" className={styles.btnSubmit}>
          Submit
        </button>
        {error && <div className={styles.error}>{error}</div>}
        {message && <div className={styles.success}>{message}</div>}
      </form>

      <TransactionHistory transactions={transactions} />
    </>
  );
}

export default AddTransaction;