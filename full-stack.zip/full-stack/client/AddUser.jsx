import React, { useState } from "react";
import styles from "./AddUser.module.css";
import { Link } from "react-router-dom";
import Logout from "./Logout";
import { createUser } from "./Auth";

function AddUser() {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("CLIENT");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitted(true);
    setError("");
    setMessage("");

    if (!userId || !password || !role) {
      return;
    }

    try {
      const response = await createUser({ userId, password, role });
      setMessage(response.success || "User created successfully");
      setUserId("");
      setPassword("");
      setRole("CLIENT");
      setSubmitted(false);
    } catch (err) {
      setError(err.message || "Failed to create user");
    }
  };

  return (
    <>
      <Logout />
      <form className={styles.userForm} onSubmit={handleSubmit}>
        <div className={styles.formGroup}>
          <label>UserId:</label>
          <input
            data-testid="userId"
            type="text"
            id="userId"
            className={styles.formControl}
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
          {submitted && !userId && <p className={styles.error}>UserId is required</p>}
        </div>
        <div className={styles.formGroup}>
          <label>Password:</label>
          <input
            data-testid="password"
            type="password"
            id="password"
            className={styles.formControl}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {submitted && !password && <p className={styles.error}>Password is required</p>}
        </div>
        <div className={styles.formGroup}>
          <label>Role:</label>
          <select
            data-testid="role"
            className={styles.formControl}
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="CLIENT">Client</option>
            <option value="ADMIN">Admin</option>
          </select>
          {submitted && !role && <p className={styles.error}>Role is required</p>}
        </div>

        <button type="submit" className={styles.btnSubmit}>
          Create User
        </button>

        {error && <div className={styles.error}>{error}</div>}

        {message && <div className={styles.success}>{message}</div>}

        <Link to={"/users"} className={styles.userList}>
          Go to User List
        </Link>
      </form>
    </>
  );
}

export default AddUser;